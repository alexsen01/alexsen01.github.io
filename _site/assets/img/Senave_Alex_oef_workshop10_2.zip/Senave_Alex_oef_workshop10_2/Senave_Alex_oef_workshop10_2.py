# gebaseerd op een internet voorbeeld
# grondig verder uitgewerkt/aangepast/uitgebreid/gecorrigeerd

from tkinter import *
from random import choice

class MyGalgje():
    WOORDEN_LIJST = []
    def __init__(self, root,keuze):
        file=str('words')+str(keuze)+str('.txt')
        fp= open(file,'r')
        for word in fp:
            self.WOORDEN_LIJST.append(word.strip())
        fp.close()

        self.root = root
        root.title("Galgje - Senave Alex")

        self.strikes = 0
        self.word = choice(self.WOORDEN_LIJST).upper()
        self.word_underscored = ["_"] * len(self.word)
        self.guess = ""
        self.guessed = "INGEGEVEN: "
        self.photo = PhotoImage(file="images/hangman01.png")

        self.canvas = Canvas(root, width=600, height=500)
        self.canvas.grid(row=0, columnspan=3)
        self.canvas.create_image(340, 240, image=self.photo)

        self.word_blank = StringVar()
        self.word_blank.set(" _ " * len(self.word))
        self.word_blank_label = Label(root, textvariable=self.word_blank)
        self.word_blank_label.grid(row=1, column=0, sticky=W+E)

        self.enter_letter_label = Label(root, text="Geef letter: ")
        self.enter_letter_label.grid(row=1, column=1, sticky=W+E)

        letterfield = root.register(self.validate)

        self.entry = Entry(root, validate="key", validatecommand=(letterfield, "%P"))
        self.entry.grid(row=1, columnspan=4, column=2, sticky=W+E)

        self.guesses = StringVar()
        self.guesses.set(self.guessed)
        self.guesses_label = Label(root, textvariable=self.guesses)
        self.guesses_label.grid(row=2, column=3, sticky=W)

        self.new = Button(root, text="Opnieuw spelen", command=self.new_game)
        self.new.grid(row=2, column=1, sticky=W+E)

        self.submit = Button(root, text="Submit", command=self.check_guess)
        self.submit.grid(row=2, column=2, sticky=W+E)

    def change_image(self):
        image_lst = ["images/hangman01.png","images/hangman02.png","images/hangman03.png","images/hangman04.png",
                    "images/hangman05.png", "images/hangman06.png","images/hangman07.png","images/hangman08.png",
                    "images/hangman09.png", "images/hangman10.png","images/hangman11.png"]
        self.strikes = self.strikes % len(image_lst)
        self.photo = PhotoImage(file=image_lst[self.strikes])
        self.canvas.create_image(340, 240, image=self.photo)

    def validate(self, text):
        if not text:
            return True
        else:
            try:
                self.guess = text.upper()
                return True
            except:
                return False

    def new_game(self):
        self.strikes = 0
        self.change_image()
        self.word = choice(self.WOORDEN_LIJST).upper()
        self.word_blank.set(" _ " * len(self.word))
        self.word_underscored = ["_"] * len(self.word)
        self.guessed = "INGEGEVEN: "
        self.guesses.set(self.guessed)

    def check_guess(self):
        if self.guess in self.guessed[10:]:
            self.entry.delete(0, END)
            return
        if len(self.guess)>1 and len(self.guess) != len(self.word): 
            self.entry.delete(0, END)
            return
        elif len(self.guess) == len(self.word):
            if self.guess==self.word:
                self.guesses.set("Gewonnen!")
                self.word_blank.set(self.word)
            else:
                self.strikes +=1
                self.change_image()
        else:
            self.guessed += self.guess
            self.guesses.set(self.guessed)
            if self.guessed[-1] not in self.word:
                self.strikes += 1
                self.change_image()
            else:
                self.word_form()
            if "_" in self.word_underscored:
                if self.strikes == 10: 
                    self.word_blank.set(self.word)
                    self.guesses.set("Je verliest.")
            if ''.join(self.word_underscored) == self.word:
                self.guesses.set("Gewonnen!")
                self.word_blank.set(self.word)
        self.entry.delete(0, END) 

    def word_form(self):
        if self.guessed[-1] in self.word:
            for index, letter in enumerate(self.word_underscored):
                if self.word[index] == self.guessed[-1]:
                    self.word_underscored[index] = self.word[index]
        self.word_blank.set(str(self.word_underscored))

def main(keuze):
    root = Tk()
    app = MyGalgje(root,keuze)
    root.mainloop()

def hoofdprogramma():
    repeat=""
    keuze=0
    while keuze==0:
        try:
            keuze=int(input('\nwoordlengte: 4/5/6/7?: '))
            if keuze not in range(4,8): 
                print('verkeerde keuze')
                keuze=0
        except:
            print('verkeerde keuze\n')
            keuze=0
    print('bij eerste uitvoering van het programma, kijk op de taskbar')
    main(keuze)
    while repeat=="":
        try:
            repeat=input('\nwil u het spel opnieuw uitvoeren? (ja/nee)')
            if repeat not in ("ja","nee"):
                print('verkeerde input')
                repeat=""
        except:
            print('verkeerde input\n')
            repeat="" 
    if repeat=="ja":
        hoofdprogramma()
    else:
        exit

hoofdprogramma()
