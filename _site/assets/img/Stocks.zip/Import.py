import datetime as dt
import os
import glob
import pandas as pd
from yahoofinancials import YahooFinancials
#import yfinance as yfin
import openpyxl as xl
#yfin.pdr_override() 

end_date = (dt.date.today()).strftime('%Y-%m-%d')
beg_date = (dt.date.today()-dt.timedelta(5*365)).strftime('%Y-%m-%d')

if not os.path.exists('C:\\STOCK\\stock_dfs'):
    os.makedirs('C:\\STOCK\\stock_dfs')

#wb = load_workbook('Brussel_Euronext_beperkt.xlsx')  # beurs van brussel
wb = xl.load_workbook('C:\\STOCK\\NASDAQ.xlsx') #Nasdaq 
#xlsx op correcte plaats + naam + niet leeg (geen check op dit gedaan)
ws=wb.active
rijen=ws.max_row
rij=str("C2:C"+str(rijen)) 
naam=str("A2:A"+str(rijen)) #ook A2 meenemen, voor de naam van het aandeel

tickers = ws[rij] 
afz_ticker=[] 

namen=ws[naam]
afz_naam=[]

for row in ws[rij]:
    #print('rij is',row)
    afz_ticker_el=[x.value for x in row] #via een append toevoegen aan lege lijst
    afz_ticker.append(afz_ticker_el)    
    print('afz_ticker',afz_ticker)

for row2 in ws[naam]:
    afz_naam_el=[x.value for x in row2] #via een append toevoegen aan lege lijst
    afz_naam.append(afz_naam_el)
  
    
total_attempts=6 
attempt = 0 

ticker_attempt=0
ticker_teller=0


while ticker_teller <rijen-1: 
    try:
        print("-------------------------------------")
        ticker=afz_ticker[ticker_teller]
        naam=afz_naam[ticker_teller]
        print('begin aandeel ',ticker_teller+1,' met ticker',afz_ticker[ticker_teller])
        print("-------------------------------------")
        while ticker_attempt<=total_attempts:     
            try:
                yahoo_financials = YahooFinancials(ticker)
                if not os.path.exists('C:\\STOCK\\stock_dfs\\{}.csv'.format(ticker[0])):
                    json_obj = yahoo_financials.get_historical_price_data(beg_date,end_date,"daily")
                    start_end= json_obj[ticker[0]]['prices']
                    temp1_df = pd.DataFrame(start_end)[["formatted_date","open","high","low","adjclose","volume"]]
                    temp1_df.set_index("formatted_date",inplace=True)
                    temp2_df = temp1_df[~temp1_df.index.duplicated(keep='first')]
                    temp2_df.to_csv('C:\\STOCK\\stock_dfs\\{}.csv'.format(ticker[0]))
                    file='C:\\STOCK\\stock_dfs\\{}.csv'.format(ticker[0])
                    csv_input=pd.read_csv(file)
                    csv_input.insert(loc=0,column='ticker',value=ticker[0])
                    csv_input.insert(loc=1,column='name',value=naam[0]) 
                    csv_input.insert(loc=2,column='per',value='D') 
                    csv_input.to_csv(file,index=False)
                    csv_input=pd.read_csv(file,skiprows=1) #oude header eruit halen
                    print(csv_input.head())
                    csv_input.to_csv(file,index=False)
                    csv_input.to_csv(file,header=["<TICKER>","<NAME>","<PER>","<DTYYMMDD>","<OPEN>","<HIGH>","<LOW>","<CLOSE>","<VOL>"],index=False)
                    csv_input=pd.read_csv(file)
                    csv_input["<DTYYMMDD>"] = csv_input["<DTYYMMDD>"].replace('-', '', regex=True).astype(int) #date format
                    csv_input.to_csv(file,index=False)
                    df = pd.concat(map(pd.read_csv, glob.glob('C:\\STOCK\\stock_dfs\\*.csv')))
                    df.to_csv("C:\\STOCK\\Markt.csv",index=False)
                    ticker_attempt=total_attempts+1
                else:
                    print('\n      already have {} \n'.format(ticker[0]))
                    ticker_attempt=total_attempts+1
            except:
                print(ticker[0],":failed to fetch data...retrying")
                ticker_attempt+=1
                continue
    except:
        print('fout')
        break
    else:
        ticker_teller+=1
        ticker_attempt=0
               